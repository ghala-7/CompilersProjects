package core;

public enum ActionType {
    ACC,S,R
}
